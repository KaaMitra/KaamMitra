let map;
let marker;

function initMap() {
  const defaultLocation = { lat: 28.6139, lng: 77.2090 }; // Delhi

  map = new google.maps.Map(document.getElementById("map"), {
    center: defaultLocation,
    zoom: 10,
  });

  marker = new google.maps.Marker({
    position: defaultLocation,
    map: map,
    draggable: true,
  });

  updateLocationText(defaultLocation);

  google.maps.event.addListener(marker, 'dragend', function(event) {
    updateLocationText({
      lat: event.latLng.lat(),
      lng: event.latLng.lng()
    });
  });

  map.addListener("click", (event) => {
    marker.setPosition(event.latLng);
    updateLocationText({
      lat: event.latLng.lat(),
      lng: event.latLng.lng()
    });
  });
}

function updateLocationText(location) {
  document.getElementById("location").textContent =
    `Lat: ${location.lat}, Lng: ${location.lng}`;
}
